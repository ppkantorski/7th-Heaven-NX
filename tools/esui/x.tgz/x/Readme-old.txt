Changelog

2.2

Integrated 7h 2.0 support
Simplified options
Added Miniminalistic NBB theme.

2.26

Improved New Threat Compatibility, thank you to Sega Chief for working with me on this.
Menu Overhaul dialog boxes are now ESUI dialog boxes
Fixed dialog boxes in Mansion on New Threat
Fixed top of dialog boxes cutoff
Fixed dialog boxes scrolling text visible on thinnest borders
Added controller buttons to all color pallettes allowing New Threat controller icon's.
Added new font spacing implementation.
Fixed font spacing on save/load screen.
Stick icons replaced with triggers for Xbox, this is for upcoming updates by unabomb/trueodin to use triggers.
Added font spacing to support extra Xbox icons so Stick Icons can still work as new font characters.  Should anyone want to use them.

2.27

Rolled back dialog box adjustments, it caused too many things to break.
Removed extra stick icons, they may or may not be added back in future.

2.28/2.29 (forgot which)

Dialog boxes fixed again, this time properly.

2.3

Integrated DDS textures into main package.  This is now much bigger when unpacked, download size is still small.
Added button mapping options for config screem, 7h is designed for xinput, so mappings are for that, but if FFNX driver used, then enable the option for dinput mappings.  If using PSX controller with 7h driver, then use ds4windows software.

2.32

FFNX Button Mapping on by default for config screen now, with 7h 2.2 in public beta (this uses FFNX by default)
Fix hext for button config screen, ok/cancel was reversed
Improved Battle Semi Transparency on the v1 optimised theme, sorry guys, I only tested before on v2 themes.
Weakened semi transparency to improve readability (same as FFNX).
Trimmed battle Limit Box width on v1 optimised theme.
Improved shop cursor alignment
Redone Cait Sith reel alignments so should be good on all options now
Fixed border width issues on stock and medium borders in battle
On the NBB 3 column battle theme, the magic menu is now removed from screen on cure/heal action so the status can be drawn to left of character names
Fixed Stock dialog option, was broken in last version
Cleaned up various hext files.
